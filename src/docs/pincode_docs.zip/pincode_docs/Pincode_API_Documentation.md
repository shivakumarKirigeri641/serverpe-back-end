# Pincode API Documentation

**Version:** 1.0  
**Last Updated:** December 19, 2025  
**API Base URL:** `/mockapis/serverpeuser/api/pincodes`

---

## Table of Contents

1. [Overview](#overview)
2. [Authentication & Authorization](#authentication--authorization)
3. [API Rate Limiting](#api-rate-limiting)
4. [Endpoints](#endpoints)
   - [States & Territories](#1-get-states--territories)
   - [Districts](#2-get-districts)
   - [Blocks](#3-get-blocks)
   - [Branch Types](#4-get-branch-types)
   - [Pincode List](#5-get-pincode-list)
   - [Pincode Details](#6-get-pincode-details)
   - [All Pincodes](#7-get-all-pincodes)
5. [Response Structure](#response-structure)
6. [Error Handling](#error-handling)
7. [Data Definitions](#data-definitions)
8. [Implementation Notes](#implementation-notes)

---

## Overview

The Pincode API provides comprehensive access to Indian postal code (pincode) database including states, districts, blocks, postal categories (branch types), and detailed pincode information. This API enables developers to build location-based services, address lookups, and postal delivery tracking systems for the Indian market.

### Key Features

- **Hierarchical Location Data**: Browse locations by state → district → block → branch type
- **Pincode Lookup**: Get detailed information for any Indian pincode
- **Complete Postal Data**: Access comprehensive pincode database
- **Rate Limiting & Security**: Advanced security middleware with DDoS protection
- **Performance Optimized**: Cached responses with Redis integration

### Disclaimer

> **CAUTION**: The data provided by these APIs is strictly for UI testing, learning, and training purposes only. No relation exists with any live scenario or actual postal operations.

---

## Authentication & Authorization

All API requests must include valid API credentials.

### Required Headers

```
1) x-api-key       (provided after subscription)
2) x-secret-key    (provided after subscription)
```

### API Key Validation

Requests are validated through the `checkApiKey` middleware. Ensure your API key and secret key are valid before making requests. Each API key has rate-limited call allocations.

---

## API Rate Limiting

The Pincode API implements advanced rate limiting and security measures:

### Rate Limiting Policy

- **Standard Limit:** 3 requests per second
- **Scraper Detection:** 50 requests in 10-second window triggers blocking
- **Block Duration:** 1 hour for detected scrapers
- **Detection Window:** 10 seconds

### Response Header

Each API response includes a `remaining_calls` parameter:

```json
{
  "success": true,
  "remaining_calls": 69,
  "data": { ... }
}
```

**Important**: Monitor this value and implement appropriate error handling when calls are exhausted.

---

## Endpoints

### 1. Get States & Territories

Retrieves a list of all Indian states and union territories.

**Endpoint:** `GET /mockapis/serverpeuser/api/pincodes/states`

**Method:** GET

**Description:** Fetches complete list of all Indian states and union territories. This is an unchargeable reference endpoint.

**Headers:**
```
x-api-key: <your-api-key>
x-secret-key: <your-secret-key>
```

**Request Body:** None (GET request)

**Response Structure:**

```json
{
  "success": true,
  "data": [
    {
      "id": 1,
      "state_id": "AP",
      "state_name": "Andhra Pradesh"
    },
    {
      "id": 2,
      "state_id": "AR",
      "state_name": "Arunachal Pradesh"
    },
    {
      "id": 3,
      "state_id": "AS",
      "state_name": "Assam"
    }
  ]
}
```

**Status Codes:**
- `200` - Success
- `500` - Internal Server Error

**Example cURL:**
```bash
curl -X GET "http://localhost:5000/mockapis/serverpeuser/api/pincodes/states" \
  -H "x-api-key: your-api-key" \
  -H "x-secret-key: your-secret-key"
```

---

### 2. Get Districts

Retrieves all districts for a specified state.

**Endpoint:** `POST /mockapis/serverpeuser/api/pincodes/districts`

**Method:** POST

**Description:** Fetches all districts available for a given state. Requires state name as parameter.

**Headers:**
```
x-api-key: <your-api-key>
x-secret-key: <your-secret-key>
Content-Type: application/json
```

**Request Body:**

```json
{
  "selectedState": "Maharashtra"
}
```

**Request Parameters:**

| Parameter | Type   | Required | Description            | Example           |
|-----------|--------|----------|------------------------|-------------------|
| selectedState | string | Yes | State name         | "Maharashtra"     |

**Validation Rules:**
- `selectedState` field must be present
- `selectedState` cannot be null or empty

**Response Structure:**

```json
{
  "success": true,
  "remaining_calls": 68,
  "message": "success",
  "data": [
    {
      "id": 1,
      "district_id": "MH01",
      "district_name": "Mumbai",
      "state_id": "MH"
    },
    {
      "id": 2,
      "district_id": "MH02",
      "district_name": "Pune",
      "state_id": "MH"
    },
    {
      "id": 3,
      "district_id": "MH03",
      "district_name": "Nagpur",
      "state_id": "MH"
    }
  ]
}
```

**Status Codes:**
- `200` - Success
- `404` - State not found or request body missing
- `500` - Internal Server Error

**Error Response Example:**

```json
{
  "success": false,
  "remaining_calls": 68,
  "message": "State not found!",
  "data": {
    "statuscode": 404,
    "successstatus": false,
    "message": "State not found!"
  }
}
```

**Example cURL:**
```bash
curl -X POST "http://localhost:5000/mockapis/serverpeuser/api/pincodes/districts" \
  -H "x-api-key: your-api-key" \
  -H "x-secret-key: your-secret-key" \
  -H "Content-Type: application/json" \
  -d '{"selectedState": "Maharashtra"}'
```

---

### 3. Get Blocks

Retrieves all blocks for a specified state and district combination.

**Endpoint:** `POST /mockapis/serverpeuser/api/pincodes/blocks`

**Method:** POST

**Description:** Fetches all blocks available for a given state-district combination.

**Headers:**
```
x-api-key: <your-api-key>
x-secret-key: <your-secret-key>
Content-Type: application/json
```

**Request Body:**

```json
{
  "selectedState": "Maharashtra",
  "selectedDistrict": "Mumbai"
}
```

**Request Parameters:**

| Parameter | Type   | Required | Description            | Example           |
|-----------|--------|----------|------------------------|-------------------|
| selectedState | string | Yes | State name         | "Maharashtra"     |
| selectedDistrict | string | Yes | District name      | "Mumbai"          |

**Validation Rules:**
- Both `selectedState` and `selectedDistrict` fields must be present
- Neither field can be null or empty

**Response Structure:**

```json
{
  "success": true,
  "remaining_calls": 67,
  "message": "success",
  "data": [
    {
      "id": 1,
      "block_id": "MH01BLK01",
      "block_name": "Mumbai Central",
      "district_id": "MH01"
    },
    {
      "id": 2,
      "block_id": "MH01BLK02",
      "block_name": "Mumbai East",
      "district_id": "MH01"
    }
  ]
}
```

**Status Codes:**
- `200` - Success
- `404` - State/District not found or request body missing
- `500` - Internal Server Error

**Example cURL:**
```bash
curl -X POST "http://localhost:5000/mockapis/serverpeuser/api/pincodes/blocks" \
  -H "x-api-key: your-api-key" \
  -H "x-secret-key: your-secret-key" \
  -H "Content-Type: application/json" \
  -d '{"selectedState": "Maharashtra", "selectedDistrict": "Mumbai"}'
```

---

### 4. Get Branch Types

Retrieves all postal branch types for a specified state, district, and block combination.

**Endpoint:** `POST /mockapis/serverpeuser/api/pincodes/branchtypes`

**Method:** POST

**Description:** Fetches all branch types (postal categories) available for a given state-district-block combination.

**Headers:**
```
x-api-key: <your-api-key>
x-secret-key: <your-secret-key>
Content-Type: application/json
```

**Request Body:**

```json
{
  "selectedState": "Maharashtra",
  "selectedDistrict": "Mumbai",
  "selectedBlock": "Mumbai Central"
}
```

**Request Parameters:**

| Parameter | Type   | Required | Description            | Example           |
|-----------|--------|----------|------------------------|-------------------|
| selectedState | string | Yes | State name         | "Maharashtra"     |
| selectedDistrict | string | Yes | District name      | "Mumbai"          |
| selectedBlock | string | Yes | Block name         | "Mumbai Central"  |

**Validation Rules:**
- All three fields must be present
- None of the fields can be null or empty

**Response Structure:**

```json
{
  "success": true,
  "remaining_calls": 66,
  "message": "success",
  "data": [
    {
      "id": 1,
      "type_id": "HO",
      "type_name": "Head Office",
      "block_id": "MH01BLK01"
    },
    {
      "id": 2,
      "type_id": "BO",
      "type_name": "Branch Office",
      "block_id": "MH01BLK01"
    },
    {
      "id": 3,
      "type_id": "SO",
      "type_name": "Sub Office",
      "block_id": "MH01BLK01"
    }
  ]
}
```

**Status Codes:**
- `200` - Success
- `404` - State/District/Block not found or request body missing
- `500` - Internal Server Error

**Example cURL:**
```bash
curl -X POST "http://localhost:5000/mockapis/serverpeuser/api/pincodes/branchtypes" \
  -H "x-api-key: your-api-key" \
  -H "x-secret-key: your-secret-key" \
  -H "Content-Type: application/json" \
  -d '{"selectedState": "Maharashtra", "selectedDistrict": "Mumbai", "selectedBlock": "Mumbai Central"}'
```

---

### 5. Get Pincode List

Retrieves complete pincode list for a specified state, district, block, and branch type.

**Endpoint:** `POST /mockapis/serverpeuser/api/pincodes/pincode-list`

**Method:** POST

**Description:** Fetches complete pincode details for a given state-district-block-branchtype combination.

**Headers:**
```
x-api-key: <your-api-key>
x-secret-key: <your-secret-key>
Content-Type: application/json
```

**Request Body:**

```json
{
  "selectedState": "Maharashtra",
  "selectedDistrict": "Mumbai",
  "selectedBlock": "Mumbai Central",
  "selectedBranchType": "Head Office"
}
```

**Request Parameters:**

| Parameter | Type   | Required | Description                   | Example           |
|-----------|--------|----------|-------------------------------|-------------------|
| selectedState | string | Yes | State name                 | "Maharashtra"     |
| selectedDistrict | string | Yes | District name              | "Mumbai"          |
| selectedBlock | string | Yes | Block name                 | "Mumbai Central"  |
| selectedBranchType | string | Yes | Branch type/category   | "Head Office"     |

**Validation Rules:**
- All four fields must be present
- None of the fields can be null or empty

**Response Structure:**

```json
{
  "success": true,
  "remaining_calls": 65,
  "message": "success",
  "data": [
    {
      "id": 1,
      "pincode": "400001",
      "office_name": "Mumbai GPO",
      "office_type": "Head Office",
      "state": "Maharashtra",
      "district": "Mumbai",
      "block": "Mumbai Central",
      "region": "Mumbai Region",
      "circle": "Mumbai Circle"
    },
    {
      "id": 2,
      "pincode": "400002",
      "office_name": "Mumbai Fort",
      "office_type": "Head Office",
      "state": "Maharashtra",
      "district": "Mumbai",
      "block": "Mumbai Central",
      "region": "Mumbai Region",
      "circle": "Mumbai Circle"
    }
  ]
}
```

**Status Codes:**
- `200` - Success
- `404` - State/District/Block/BranchType not found or request body missing
- `500` - Internal Server Error

**Example cURL:**
```bash
curl -X POST "http://localhost:5000/mockapis/serverpeuser/api/pincodes/pincode-list" \
  -H "x-api-key: your-api-key" \
  -H "x-secret-key: your-secret-key" \
  -H "Content-Type: application/json" \
  -d '{"selectedState": "Maharashtra", "selectedDistrict": "Mumbai", "selectedBlock": "Mumbai Central", "selectedBranchType": "Head Office"}'
```

---

### 6. Get Pincode Details

Retrieves detailed information for a specific pincode.

**Endpoint:** `POST /mockapis/serverpeuser/api/pincode-details`

**Method:** POST

**Description:** Fetches comprehensive details for a specific pincode including location and delivery information.

**Headers:**
```
x-api-key: <your-api-key>
x-secret-key: <your-secret-key>
Content-Type: application/json
```

**Request Body:**

```json
{
  "pincode": "400001"
}
```

**Request Parameters:**

| Parameter | Type   | Required | Description                    | Example |
|-----------|--------|----------|--------------------------------|---------|
| pincode   | string | Yes      | Indian postal code             | "400001"|

**Validation Rules:**
- `pincode` field must be present
- `pincode` must be a valid 6-digit number

**Response Structure:**

```json
{
  "success": true,
  "remaining_calls": 64,
  "data": {
    "pincode": "400001",
    "office_name": "Mumbai GPO",
    "office_type": "Head Office",
    "state": "Maharashtra",
    "state_id": "MH",
    "district": "Mumbai",
    "district_id": "MH01",
    "block": "Mumbai Central",
    "block_id": "MH01BLK01",
    "region": "Mumbai Region",
    "circle": "Mumbai Circle",
    "delivery_type": "Head Office",
    "taluk": "Mumbai",
    "sub_division": "Mumbai",
    "latitude": 18.9676,
    "longitude": 72.8194,
    "population": "Over 20 million"
  }
}
```

**Status Codes:**
- `200` - Success
- `404` - Pincode not found or request body missing
- `422` - Invalid pincode format
- `500` - Internal Server Error

**Error Response Example:**

```json
{
  "success": true,
  "remaining_calls": 64,
  "data": {
    "statuscode": 404,
    "successstatus": false,
    "message": "Pincode not found!"
  }
}
```

**Example cURL:**
```bash
curl -X POST "http://localhost:5000/mockapis/serverpeuser/api/pincode-details" \
  -H "x-api-key: your-api-key" \
  -H "x-secret-key: your-secret-key" \
  -H "Content-Type: application/json" \
  -d '{"pincode": "400001"}'
```

---

### 7. Get All Pincodes

Retrieves the complete pincode database.

**Endpoint:** `GET /mockapis/serverpeuser/api/pincodes`

**Method:** GET

**Description:** Fetches all pincodes from the database. This endpoint returns the complete pincode dataset.

**Headers:**
```
x-api-key: <your-api-key>
x-secret-key: <your-secret-key>
```

**Request Body:** None (GET request)

**Response Structure:**

```json
{
  "success": true,
  "remaining_calls": 63,
  "data": [
    {
      "id": 1,
      "pincode": "400001",
      "office_name": "Mumbai GPO",
      "office_type": "Head Office",
      "state": "Maharashtra",
      "district": "Mumbai",
      "block": "Mumbai Central"
    },
    {
      "id": 2,
      "pincode": "400002",
      "office_name": "Mumbai Fort",
      "office_type": "Head Office",
      "state": "Maharashtra",
      "district": "Mumbai",
      "block": "Mumbai Central"
    }
  ]
}
```

**Status Codes:**
- `200` - Success
- `500` - Internal Server Error

**Example cURL:**
```bash
curl -X GET "http://localhost:5000/mockapis/serverpeuser/api/pincodes" \
  -H "x-api-key: your-api-key" \
  -H "x-secret-key: your-secret-key"
```

---

## Response Structure

### Standard Success Response

All successful API responses follow this structure:

```json
{
  "success": true,
  "remaining_calls": 70,
  "message": "success",
  "data": { /* endpoint-specific data */ }
}
```

### Standard Error Response

Error responses maintain the same structure:

```json
{
  "success": false,
  "remaining_calls": 70,
  "message": "Error message",
  "data": {
    "statuscode": 404,
    "successstatus": false,
    "message": "Detailed error message"
  }
}
```

---

## Error Handling

### HTTP Status Codes

| Status Code | Meaning                              |
|-------------|--------------------------------------|
| 200         | Request successful                   |
| 400         | Bad request                          |
| 404         | Resource not found                   |
| 422         | Unprocessable entity (validation)    |
| 429         | Too many requests (rate limited)     |
| 500         | Internal server error                |

### Common Error Messages

| Message                                    | Cause                                    |
|--------------------------------------------|------------------------------------------|
| "Request body information not found!"     | Missing request body                     |
| "State not found!"                        | `selectedState` parameter missing/invalid|
| "selectedState not found!"                | Invalid state name provided              |
| "selectedDistrict not found!"             | `selectedDistrict` parameter missing/invalid|
| "selectedBlock not found!"                | `selectedBlock` parameter missing/invalid|
| "selectedBranchType not found!"           | `selectedBranchType` parameter missing   |
| "pincode not found!"                      | `pincode` parameter missing              |
| "Pincode not found!"                      | Pincode not in database                  |
| "Pincode is invalid!"                     | Pincode format is incorrect              |
| "Internal Server Error"                   | Server-side error occurred               |

### Error Handling Best Practices

1. **Always check the `success` field** in the response
2. **Monitor `remaining_calls`** to avoid exceeding rate limits
3. **Implement exponential backoff** for retry logic
4. **Log error responses** for debugging purposes
5. **Handle rate limiting gracefully** with appropriate user feedback

---

## Data Definitions

### State Object

```json
{
  "id": 1,
  "state_id": "MH",
  "state_name": "Maharashtra"
}
```

| Field     | Type   | Description                  |
|-----------|--------|------------------------------|
| id        | int    | Internal database ID         |
| state_id  | string | State code (2-letter)        |
| state_name| string | State name                   |

### District Object

```json
{
  "id": 1,
  "district_id": "MH01",
  "district_name": "Mumbai",
  "state_id": "MH"
}
```

| Field       | Type | Description              |
|-------------|------|--------------------------|
| id          | int  | Internal database ID     |
| district_id | string| District code           |
| district_name| string| District name           |
| state_id    | string| Parent state ID         |

### Block Object

```json
{
  "id": 1,
  "block_id": "MH01BLK01",
  "block_name": "Mumbai Central",
  "district_id": "MH01"
}
```

| Field    | Type   | Description            |
|----------|--------|------------------------|
| id       | int    | Internal database ID   |
| block_id | string | Block code             |
| block_name| string | Block name            |
| district_id| string | Parent district ID    |

### Branch Type Object

```json
{
  "id": 1,
  "type_id": "HO",
  "type_name": "Head Office",
  "block_id": "MH01BLK01"
}
```

| Field    | Type   | Description              |
|----------|--------|--------------------------|
| id       | int    | Internal database ID     |
| type_id  | string | Branch type code         |
| type_name| string | Branch type name         |
| block_id | string | Parent block ID          |

### Pincode Object

```json
{
  "id": 1,
  "pincode": "400001",
  "office_name": "Mumbai GPO",
  "office_type": "Head Office",
  "state": "Maharashtra",
  "state_id": "MH",
  "district": "Mumbai",
  "district_id": "MH01",
  "block": "Mumbai Central",
  "block_id": "MH01BLK01",
  "region": "Mumbai Region",
  "circle": "Mumbai Circle",
  "delivery_type": "Head Office",
  "taluk": "Mumbai",
  "sub_division": "Mumbai",
  "latitude": 18.9676,
  "longitude": 72.8194,
  "population": "Over 20 million"
}
```

| Field        | Type   | Description                 |
|--------------|--------|------------------------------|
| id           | int    | Internal database ID        |
| pincode      | string | 6-digit postal code         |
| office_name  | string | Postal office name          |
| office_type  | string | Type of postal office       |
| state        | string | State name                  |
| state_id     | string | State code                  |
| district     | string | District name               |
| district_id  | string | District code               |
| block        | string | Block/Taluk name            |
| block_id     | string | Block code                  |
| region       | string | Postal region               |
| circle       | string | Postal circle               |
| delivery_type| string | Delivery category           |
| taluk        | string | Taluk name                  |
| sub_division | string | Sub-division name           |
| latitude     | float  | Geographic latitude         |
| longitude    | float  | Geographic longitude        |
| population   | string | Area population estimate    |

---

## Implementation Notes

### Performance Optimization

1. **Caching Strategy**: Responses are cached using Redis for improved performance
2. **Connection Pooling**: Database connections are pooled and reused
3. **Query Optimization**: SQL queries are optimized for fast execution
4. **Index Strategy**: Database indexes on frequently searched fields

### Security Measures

1. **API Key Validation**: All requests validated against registered API keys
2. **DDoS Protection**: Advanced rate limiting detects and blocks scrapers
3. **Request Validation**: Input parameters validated before database queries
4. **SQL Injection Prevention**: Parameterized queries prevent SQL injection
5. **TLS Support**: Redis connections use TLS for secure data transmission

### Best Practices for API Integration

1. **Use Connection Pooling**: Reuse connections for multiple requests
2. **Implement Retry Logic**: Handle transient failures with exponential backoff
3. **Cache Results Locally**: Cache frequently accessed data on the client side
4. **Batch Operations**: Combine multiple queries when possible
5. **Monitor Usage**: Track `remaining_calls` to optimize API usage
6. **Error Logging**: Log all errors for debugging and monitoring
7. **Timeout Handling**: Implement request timeouts to prevent hanging

### Rate Limiting Strategy

- **Recommended Request Pattern**: Use 1-2 requests per second
- **Batch Size**: Limit concurrent requests to 5-10
- **Retry Delay**: Use exponential backoff (100ms, 200ms, 400ms, ...)
- **Peak Usage**: Avoid high-frequency requests during peak hours

### Known Limitations

1. Complete pincode database may contain 1000s of records
2. Hierarchical queries are sequential (state → district → block → branchtype)
3. Location data is updated quarterly
4. Geographic coordinates are approximate

---

## Changelog

### Version 1.0 (December 19, 2025)

- Initial release
- 7 core endpoints for pincode data retrieval
- Hierarchical location browsing
- Advanced rate limiting and security
- Comprehensive error handling

---

**Support & Documentation**

For additional support and technical documentation, please refer to:
- API Dashboard: https://dashboard.serverpe.com
- Support Email: support@serverpe.com
- Status Page: https://status.serverpe.com

---

**Disclaimer**

This API is provided for testing and development purposes only. Data accuracy is not guaranteed. Users should verify all information independently before making any decisions based on this API's data.

---

*Last Updated: December 19, 2025*
*API Version: 1.0*
