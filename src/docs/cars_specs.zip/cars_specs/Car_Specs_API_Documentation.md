# Car Specifications API Documentation

**Version:** 1.0  
**Last Updated:** December 19, 2025  
**API Base URL:** `/mockapis/serverpeuser/api/carspecs`

---

## Table of Contents

1. [Overview](#overview)
2. [Authentication & Authorization](#authentication--authorization)
3. [API Rate Limiting](#api-rate-limiting)
4. [Endpoints](#endpoints)
   - [Car Makes](#1-get-car-makes)
   - [Car Models](#2-get-car-models)
   - [Car Series](#3-get-car-series)
   - [Car Grades](#4-get-car-grades)
   - [Car List](#5-get-car-list)
   - [Car Specifications](#6-get-car-specifications)
   - [Search Cars](#7-search-cars)
5. [Response Structure](#response-structure)
6. [Error Handling](#error-handling)
7. [Data Definitions](#data-definitions)
8. [Implementation Notes](#implementation-notes)

---

## Overview

The Car Specifications API provides comprehensive access to car database information including makes (brands), models, series, grades, and detailed specifications. This API enables developers to build car selection interfaces, search functionality, and specification lookup tools.

### Key Features

- **Hierarchical Car Data**: Browse cars by make → model → series → grade
- **Detailed Specifications**: Access complete technical specifications for any car variant
- **Search Functionality**: Full-text search across car database
- **Rate Limiting & Security**: Advanced security middleware with DDoS protection
- **Performance Optimized**: Cached responses with Redis integration

### Disclaimer

> **CAUTION**: The data provided by these APIs is strictly for UI testing, learning, and training purposes only. No relation exists with any live scenario or actual vehicle specifications.

---

## Authentication & Authorization

All API requests must include valid API credentials.

### Required Headers

```
1) x-api-key       (provided after subscription)
2) x-secret-key    (provided after subscription)
```

### API Key Validation

Requests are validated through the `checkApiKey` middleware. Ensure your API key and secret key are valid before making requests. Each API key has rate-limited call allocations.

---

## API Rate Limiting

The Car Specifications API implements advanced rate limiting and security measures:

### Rate Limiting Policy

- **Standard Limit:** 3 requests per second
- **Scraper Detection:** 50 requests in 10-second window triggers blocking
- **Block Duration:** 1 hour for detected scrapers
- **Detection Window:** 10 seconds

### Response Header

Each API response includes a `remaining_calls` parameter:

```json
{
  "success": true,
  "remaining_calls": 69,
  "data": { ... }
}
```

**Important**: Monitor this value and implement appropriate error handling when calls are exhausted.

---

## Endpoints

### 1. Get Car Makes

Retrieves a list of all available car manufacturers (makes/brands) in the database.

**Endpoint:** `GET /mockapis/serverpeuser/api/carspecs/car-makes`

**Method:** GET

**Description:** Fetches complete list of all car makes/brands without requiring any parameters.

**Headers:**
```
x-api-key: <your-api-key>
x-secret-key: <your-secret-key>
```

**Request Body:** None (GET request)

**Response Structure:**

```json
{
  "success": true,
  "data": [
    {
      "id": 1,
      "make_id": 1001,
      "make_name": "Maruti Suzuki",
      "logo_url": "https://example.com/logo/maruti.png"
    },
    {
      "id": 2,
      "make_id": 1002,
      "make_name": "Hyundai",
      "logo_url": "https://example.com/logo/hyundai.png"
    },
    {
      "id": 3,
      "make_id": 1003,
      "make_name": "Tata Motors",
      "logo_url": "https://example.com/logo/tata.png"
    }
  ]
}
```

**Status Codes:**
- `200` - Success
- `500` - Internal Server Error

**Example cURL:**
```bash
curl -X GET "http://localhost:5000/mockapis/serverpeuser/api/carspecs/car-makes" \
  -H "x-api-key: your-api-key" \
  -H "x-secret-key: your-secret-key"
```

---

### 2. Get Car Models

Retrieves all available models for a specified car brand/make.

**Endpoint:** `POST /mockapis/serverpeuser/api/carSpecs/car-models`

**Method:** POST

**Description:** Fetches all car models available for a given brand. Requires brand name as parameter.

**Headers:**
```
x-api-key: <your-api-key>
x-secret-key: <your-secret-key>
Content-Type: application/json
```

**Request Body:**

```json
{
  "brand": "Maruti Suzuki"
}
```

**Request Parameters:**

| Parameter | Type   | Required | Description              | Example           |
|-----------|--------|----------|--------------------------|-------------------|
| brand     | string | Yes      | Car manufacturer name    | "Maruti Suzuki"   |

**Validation Rules:**
- `brand` field must be present
- `brand` cannot be an empty string

**Response Structure:**

```json
{
  "success": true,
  "remaining_calls": 68,
  "data": [
    {
      "id": 101,
      "model_id": 5001,
      "model_name": "Swift",
      "make_id": 1001
    },
    {
      "id": 102,
      "model_id": 5002,
      "model_name": "Baleno",
      "make_id": 1001
    },
    {
      "id": 103,
      "model_id": 5003,
      "model_name": "Vitara Brezza",
      "make_id": 1001
    }
  ]
}
```

**Status Codes:**
- `200` - Success
- `404` - Brand not found or request body missing
- `422` - Invalid brand parameter
- `500` - Internal Server Error

**Error Response Example:**

```json
{
  "success": true,
  "remaining_calls": 68,
  "data": {
    "statuscode": 404,
    "successstatus": false,
    "message": "brand not found!"
  }
}
```

**Example cURL:**
```bash
curl -X POST "http://localhost:5000/mockapis/serverpeuser/api/carSpecs/car-models" \
  -H "x-api-key: your-api-key" \
  -H "x-secret-key: your-secret-key" \
  -H "Content-Type: application/json" \
  -d '{"brand": "Maruti Suzuki"}'
```

---

### 3. Get Car Series

Retrieves all available series (variants) for a specified brand and model combination.

**Endpoint:** `POST /mockapis/serverpeuser/api/carSpecs/car-series`

**Method:** POST

**Description:** Fetches all car series available for a given brand-model combination.

**Headers:**
```
x-api-key: <your-api-key>
x-secret-key: <your-secret-key>
Content-Type: application/json
```

**Request Body:**

```json
{
  "brand": "Maruti Suzuki",
  "model": "Swift"
}
```

**Request Parameters:**

| Parameter | Type   | Required | Description            | Example           |
|-----------|--------|----------|------------------------|-------------------|
| brand     | string | Yes      | Car manufacturer name  | "Maruti Suzuki"   |
| model     | string | Yes      | Car model name         | "Swift"           |

**Validation Rules:**
- Both `brand` and `model` fields must be present
- Neither field can be an empty string

**Response Structure:**

```json
{
  "success": true,
  "remaining_calls": 67,
  "data": [
    {
      "id": 1001,
      "series_id": 7001,
      "series_name": "LXi",
      "model_id": 5001
    },
    {
      "id": 1002,
      "series_id": 7002,
      "series_name": "VXi",
      "model_id": 5001
    },
    {
      "id": 1003,
      "series_id": 7003,
      "series_name": "ZXi",
      "model_id": 5001
    }
  ]
}
```

**Status Codes:**
- `200` - Success
- `404` - Brand/Model not found or request body missing
- `422` - Invalid brand or model parameter
- `500` - Internal Server Error

**Error Response Example:**

```json
{
  "success": true,
  "remaining_calls": 67,
  "data": {
    "statuscode": 404,
    "successstatus": false,
    "message": "model not found!"
  }
}
```

**Example cURL:**
```bash
curl -X POST "http://localhost:5000/mockapis/serverpeuser/api/carSpecs/car-series" \
  -H "x-api-key: your-api-key" \
  -H "x-secret-key: your-secret-key" \
  -H "Content-Type: application/json" \
  -d '{"brand": "Maruti Suzuki", "model": "Swift"}'
```

---

### 4. Get Car Grades

Retrieves all available grades (trim levels) for a specified brand, model, and series combination.

**Endpoint:** `POST /mockapis/serverpeuser/api/carSpecs/car-grades`

**Method:** POST

**Description:** Fetches all car grades available for a given brand-model-series combination.

**Headers:**
```
x-api-key: <your-api-key>
x-secret-key: <your-secret-key>
Content-Type: application/json
```

**Request Body:**

```json
{
  "brand": "Maruti Suzuki",
  "model": "Swift",
  "series": "LXi"
}
```

**Request Parameters:**

| Parameter | Type   | Required | Description            | Example           |
|-----------|--------|----------|------------------------|-------------------|
| brand     | string | Yes      | Car manufacturer name  | "Maruti Suzuki"   |
| model     | string | Yes      | Car model name         | "Swift"           |
| series    | string | Yes      | Car series name        | "LXi"             |

**Validation Rules:**
- All three fields (`brand`, `model`, `series`) must be present
- None of the fields can be empty strings

**Response Structure:**

```json
{
  "success": true,
  "remaining_calls": 66,
  "data": [
    {
      "id": 10001,
      "grade_id": 8001,
      "grade_name": "Manual",
      "series_id": 7001,
      "price": 580000
    },
    {
      "id": 10002,
      "grade_id": 8002,
      "grade_name": "Automatic",
      "series_id": 7001,
      "price": 650000
    }
  ]
}
```

**Status Codes:**
- `200` - Success
- `404` - Brand/Model/Series not found or request body missing
- `422` - Invalid parameter
- `500` - Internal Server Error

**Error Response Example:**

```json
{
  "success": true,
  "remaining_calls": 66,
  "data": {
    "statuscode": 404,
    "successstatus": false,
    "message": "Series not found!"
  }
}
```

**Example cURL:**
```bash
curl -X POST "http://localhost:5000/mockapis/serverpeuser/api/carSpecs/car-grades" \
  -H "x-api-key: your-api-key" \
  -H "x-secret-key: your-secret-key" \
  -H "Content-Type: application/json" \
  -d '{"brand": "Maruti Suzuki", "model": "Swift", "series": "LXi"}'
```

---

### 5. Get Car List

Retrieves detailed car records for a specified brand, model, series, and grade combination.

**Endpoint:** `POST /mockapis/serverpeuser/api/carSpecs/car-list`

**Method:** POST

**Description:** Fetches complete car list with basic information for a given brand-model-series-grade combination.

**Headers:**
```
x-api-key: <your-api-key>
x-secret-key: <your-secret-key>
Content-Type: application/json
```

**Request Body:**

```json
{
  "brand": "Maruti Suzuki",
  "model": "Swift",
  "series": "LXi",
  "grade": "Manual"
}
```

**Request Parameters:**

| Parameter | Type   | Required | Description            | Example           |
|-----------|--------|----------|------------------------|-------------------|
| brand     | string | Yes      | Car manufacturer name  | "Maruti Suzuki"   |
| model     | string | Yes      | Car model name         | "Swift"           |
| series    | string | Yes      | Car series name        | "LXi"             |
| grade     | string | Yes      | Car grade/trim level   | "Manual"          |

**Validation Rules:**
- All four fields must be present
- None of the fields can be empty strings

**Response Structure:**

```json
{
  "success": true,
  "remaining_calls": 65,
  "data": [
    {
      "id": 50001,
      "car_id": "SWIFT_LXI_MANUAL_001",
      "year": 2024,
      "color": "Red",
      "transmission": "Manual",
      "fuel_type": "Petrol",
      "engine_capacity": "1200cc",
      "price": 580000,
      "grade_id": 8001
    },
    {
      "id": 50002,
      "car_id": "SWIFT_LXI_MANUAL_002",
      "year": 2024,
      "color": "Silver",
      "transmission": "Manual",
      "fuel_type": "Petrol",
      "engine_capacity": "1200cc",
      "price": 580000,
      "grade_id": 8001
    }
  ]
}
```

**Status Codes:**
- `200` - Success
- `404` - Brand/Model/Series/Grade not found or request body missing
- `422` - Invalid parameter
- `500` - Internal Server Error

**Error Response Example:**

```json
{
  "success": true,
  "remaining_calls": 65,
  "data": {
    "statuscode": 404,
    "successstatus": false,
    "message": "grade not found!"
  }
}
```

**Example cURL:**
```bash
curl -X POST "http://localhost:5000/mockapis/serverpeuser/api/carSpecs/car-list" \
  -H "x-api-key: your-api-key" \
  -H "x-secret-key: your-secret-key" \
  -H "Content-Type: application/json" \
  -d '{"brand": "Maruti Suzuki", "model": "Swift", "series": "LXi", "grade": "Manual"}'
```

---

### 6. Get Car Specifications

Retrieves detailed technical specifications for a specific car variant by ID.

**Endpoint:** `POST /mockapis/serverpeuser/api/carSpecs/car-specs`

**Method:** POST

**Description:** Fetches comprehensive technical specifications for a car variant identified by its unique ID.

**Headers:**
```
x-api-key: <your-api-key>
x-secret-key: <your-secret-key>
Content-Type: application/json
```

**Request Body:**

```json
{
  "id": 50001
}
```

**Request Parameters:**

| Parameter | Type    | Required | Description                    | Example |
|-----------|---------|----------|--------------------------------|---------|
| id        | integer | Yes      | Unique car variant identifier  | 50001   |

**Validation Rules:**
- `id` field must be present
- `id` must be a valid numeric value

**Response Structure:**

```json
{
  "success": true,
  "remaining_calls": 64,
  "data": {
    "id": 50001,
    "car_id": "SWIFT_LXI_MANUAL_001",
    "year": 2024,
    "make": "Maruti Suzuki",
    "model": "Swift",
    "series": "LXi",
    "grade": "Manual",
    "color": "Red",
    "transmission": "Manual",
    "fuel_type": "Petrol",
    "engine_capacity": "1200cc",
    "max_power": "83 bhp",
    "torque": "113 Nm",
    "acceleration_0_100": "12.5 seconds",
    "top_speed": "180 km/h",
    "mileage": "20.5 km/l",
    "seating_capacity": 5,
    "boot_space": "268 litres",
    "length": "3.845 m",
    "width": "1.675 m",
    "height": "1.505 m",
    "ground_clearance": "170 mm",
    "kerb_weight": "860 kg",
    "fuel_tank_capacity": "35 litres",
    "price": 580000,
    "warranty": "3 years / 100,000 km",
    "features": [
      "Power Steering",
      "ABS",
      "Air Conditioning",
      "Electric Windows"
    ],
    "safety_features": [
      "Dual Airbags",
      "ABS with EBD",
      "Child Safety Locks"
    ]
  }
}
```

**Status Codes:**
- `200` - Success
- `404` - Car ID not found or request body missing
- `422` - Invalid ID parameter (non-numeric)
- `500` - Internal Server Error

**Error Response Example:**

```json
{
  "success": true,
  "remaining_calls": 64,
  "data": {
    "statuscode": 422,
    "successstatus": false,
    "message": "id is invalid!"
  }
}
```

**Example cURL:**
```bash
curl -X POST "http://localhost:5000/mockapis/serverpeuser/api/carSpecs/car-specs" \
  -H "x-api-key: your-api-key" \
  -H "x-secret-key: your-secret-key" \
  -H "Content-Type: application/json" \
  -d '{"id": 50001}'
```

---

### 7. Search Cars

Performs full-text search across the car database with pagination support.

**Endpoint:** `POST /mockapis/serverpeuser/api/carSpecs/search-cars`

**Method:** POST

**Description:** Searches for cars matching the query string across brand, model, series, and grade fields with pagination support.

**Headers:**
```
x-api-key: <your-api-key>
x-secret-key: <your-secret-key>
Content-Type: application/json
```

**Request Body:**

```json
{
  "query": "Swift",
  "limit": 20,
  "skip": 0
}
```

**Request Parameters:**

| Parameter | Type    | Required | Description                          | Example |
|-----------|---------|----------|--------------------------------------|---------|
| query     | string  | Yes      | Search query string                  | "Swift" |
| limit     | integer | Yes      | Number of results to return          | 20      |
| skip      | integer | Yes      | Number of results to skip (offset)   | 0       |

**Validation Rules:**
- `query` field must be present
- `query` cannot be an empty string
- `limit` must be a valid numeric value
- `skip` must be a valid numeric value

**Response Structure:**

```json
{
  "success": true,
  "remaining_calls": 63,
  "data": {
    "total_results": 45,
    "returned_results": 20,
    "limit": 20,
    "skip": 0,
    "results": [
      {
        "id": 50001,
        "car_id": "SWIFT_LXI_MANUAL_001",
        "make": "Maruti Suzuki",
        "model": "Swift",
        "series": "LXi",
        "grade": "Manual",
        "year": 2024,
        "price": 580000,
        "fuel_type": "Petrol",
        "transmission": "Manual"
      },
      {
        "id": 50002,
        "car_id": "SWIFT_LXI_MANUAL_002",
        "make": "Maruti Suzuki",
        "model": "Swift",
        "series": "LXi",
        "grade": "Manual",
        "year": 2024,
        "price": 580000,
        "fuel_type": "Petrol",
        "transmission": "Manual"
      }
    ]
  }
}
```

**Status Codes:**
- `200` - Success
- `404` - Query not found or request body missing
- `422` - Invalid query, limit, or skip parameter
- `500` - Internal Server Error

**Error Response Example:**

```json
{
  "success": true,
  "remaining_calls": 63,
  "data": {
    "statuscode": 422,
    "successstatus": false,
    "message": "limit is invalid!"
  }
}
```

**Example cURL:**
```bash
curl -X POST "http://localhost:5000/mockapis/serverpeuser/api/carSpecs/search-cars" \
  -H "x-api-key: your-api-key" \
  -H "x-secret-key: your-secret-key" \
  -H "Content-Type: application/json" \
  -d '{"query": "Swift", "limit": 20, "skip": 0}'
```

---

## Response Structure

### Standard Success Response

All successful API responses follow this structure:

```json
{
  "success": true,
  "remaining_calls": 70,
  "data": { /* endpoint-specific data */ }
}
```

### Standard Error Response

Error responses maintain the same structure:

```json
{
  "success": true,
  "remaining_calls": 70,
  "data": {
    "statuscode": 404,
    "successstatus": false,
    "message": "Detailed error message"
  }
}
```

---

## Error Handling

### HTTP Status Codes

| Status Code | Meaning                              |
|-------------|--------------------------------------|
| 200         | Request successful                   |
| 400         | Bad request                          |
| 404         | Resource not found                   |
| 422         | Unprocessable entity (validation)    |
| 429         | Too many requests (rate limited)     |
| 500         | Internal server error                |

### Common Error Messages

| Message                                    | Cause                                    |
|--------------------------------------------|------------------------------------------|
| "Request body information not found!"     | Missing request body                     |
| "brand not found!"                        | `brand` parameter missing               |
| "brand is invalid!"                       | `brand` parameter is empty string        |
| "model not found!"                        | `model` parameter missing               |
| "model is invalid!"                       | `model` parameter is empty string        |
| "Series not found!"                       | `series` parameter missing              |
| "series is invalid!"                      | `series` parameter is empty string       |
| "grade not found!"                        | `grade` parameter missing               |
| "grade is invalid!"                       | `grade` parameter is empty string        |
| "id not found!"                           | `id` parameter missing                  |
| "id is invalid!"                          | `id` parameter is non-numeric            |
| "search query not found!"                 | `query` parameter missing               |
| "search query is invalid!"                | `query` parameter is empty string        |
| "limit is invalid!"                       | `limit` parameter is non-numeric         |
| "skip is invalid!"                        | `skip` parameter is non-numeric          |
| "Internal Server Error"                   | Server-side error occurred               |

### Error Handling Best Practices

1. **Always check the `success` field** in the response
2. **Monitor `remaining_calls`** to avoid exceeding rate limits
3. **Implement exponential backoff** for retry logic
4. **Log error responses** for debugging purposes
5. **Handle rate limiting gracefully** with appropriate user feedback

---

## Data Definitions

### Make Object

```json
{
  "id": 1,
  "make_id": 1001,
  "make_name": "Maruti Suzuki",
  "logo_url": "https://example.com/logo/maruti.png"
}
```

| Field    | Type   | Description                  |
|----------|--------|------------------------------|
| id       | int    | Internal database ID         |
| make_id  | int    | Unique manufacturer ID       |
| make_name| string | Manufacturer name            |
| logo_url | string | URL to manufacturer logo     |

### Model Object

```json
{
  "id": 101,
  "model_id": 5001,
  "model_name": "Swift",
  "make_id": 1001
}
```

| Field    | Type | Description            |
|----------|------|------------------------|
| id       | int  | Internal database ID   |
| model_id | int  | Unique model ID        |
| model_name| string| Car model name        |
| make_id  | int  | Parent make ID        |

### Series Object

```json
{
  "id": 1001,
  "series_id": 7001,
  "series_name": "LXi",
  "model_id": 5001
}
```

| Field    | Type   | Description            |
|----------|--------|------------------------|
| id       | int    | Internal database ID   |
| series_id| int    | Unique series ID       |
| series_name| string| Car series name       |
| model_id | int    | Parent model ID        |

### Grade Object

```json
{
  "id": 10001,
  "grade_id": 8001,
  "grade_name": "Manual",
  "series_id": 7001,
  "price": 580000
}
```

| Field    | Type    | Description            |
|----------|---------|------------------------|
| id       | int     | Internal database ID   |
| grade_id | int     | Unique grade ID        |
| grade_name| string  | Car grade/trim name    |
| series_id| int     | Parent series ID       |
| price    | float   | Price in INR           |

### Car Specifications Object

```json
{
  "id": 50001,
  "car_id": "SWIFT_LXI_MANUAL_001",
  "year": 2024,
  "make": "Maruti Suzuki",
  "model": "Swift",
  "series": "LXi",
  "grade": "Manual",
  "color": "Red",
  "transmission": "Manual",
  "fuel_type": "Petrol",
  "engine_capacity": "1200cc",
  "max_power": "83 bhp",
  "torque": "113 Nm",
  "acceleration_0_100": "12.5 seconds",
  "top_speed": "180 km/h",
  "mileage": "20.5 km/l",
  "seating_capacity": 5,
  "boot_space": "268 litres",
  "length": "3.845 m",
  "width": "1.675 m",
  "height": "1.505 m",
  "ground_clearance": "170 mm",
  "kerb_weight": "860 kg",
  "fuel_tank_capacity": "35 litres",
  "price": 580000,
  "warranty": "3 years / 100,000 km",
  "features": [],
  "safety_features": []
}
```

| Field              | Type     | Description                      |
|-------------------|----------|----------------------------------|
| id                | int      | Internal database ID             |
| car_id            | string   | Unique car identifier            |
| year              | int      | Model year                       |
| make              | string   | Manufacturer name                |
| model             | string   | Model name                       |
| series            | string   | Series/variant name              |
| grade             | string   | Grade/trim level                 |
| color             | string   | Car color                        |
| transmission      | string   | Manual/Automatic                 |
| fuel_type         | string   | Petrol/Diesel/Hybrid/Electric    |
| engine_capacity   | string   | Engine displacement              |
| max_power         | string   | Maximum power output             |
| torque            | string   | Maximum torque                   |
| acceleration_0_100| string   | 0-100 km/h time                  |
| top_speed         | string   | Maximum speed                    |
| mileage           | string   | Fuel efficiency (km/l)           |
| seating_capacity  | int      | Number of seats                  |
| boot_space        | string   | Boot/trunk capacity              |
| length            | string   | Overall length                   |
| width             | string   | Overall width                    |
| height            | string   | Overall height                   |
| ground_clearance  | string   | Ground clearance                 |
| kerb_weight       | string   | Vehicle weight                   |
| fuel_tank_capacity| string   | Fuel tank volume                 |
| price             | float    | Price in INR                     |
| warranty          | string   | Warranty period and coverage     |
| features          | array    | List of car features             |
| safety_features   | array    | List of safety features          |

---

## Implementation Notes

### Performance Optimization

1. **Caching Strategy**: Responses are cached using Redis for improved performance
2. **Connection Pooling**: Database connections are pooled and reused
3. **Query Optimization**: SQL queries are optimized for fast execution
4. **Index Strategy**: Database indexes on frequently searched fields

### Security Measures

1. **API Key Validation**: All requests validated against registered API keys
2. **DDoS Protection**: Advanced rate limiting detects and blocks scrapers
3. **Request Validation**: Input parameters validated before database queries
4. **SQL Injection Prevention**: Parameterized queries prevent SQL injection
5. **TLS Support**: Redis connections use TLS for secure data transmission

### Best Practices for API Integration

1. **Use Connection Pooling**: Reuse connections for multiple requests
2. **Implement Retry Logic**: Handle transient failures with exponential backoff
3. **Cache Results Locally**: Cache frequently accessed data on the client side
4. **Batch Operations**: Combine multiple queries when possible
5. **Monitor Usage**: Track `remaining_calls` to optimize API usage
6. **Error Logging**: Log all errors for debugging and monitoring
7. **Timeout Handling**: Implement request timeouts to prevent hanging

### Rate Limiting Strategy

- **Recommended Request Pattern**: Use 1-2 requests per second
- **Batch Size**: Limit concurrent requests to 5-10
- **Retry Delay**: Use exponential backoff (100ms, 200ms, 400ms, ...)
- **Peak Usage**: Avoid high-frequency requests during peak hours

### Known Limitations

1. Search results limited to 1000 records maximum
2. Single request limit: 100 records per pagination
3. Make list is static and updated quarterly
4. Specifications may vary based on data source

---

## Changelog

### Version 1.0 (December 19, 2025)

- Initial release
- 7 core endpoints for car data retrieval
- Full-text search functionality
- Advanced rate limiting and security
- Comprehensive error handling

---

**Support & Documentation**

For additional support and technical documentation, please refer to:
- API Dashboard: https://dashboard.serverpe.com
- Support Email: support@serverpe.com
- Status Page: https://status.serverpe.com

---

**Disclaimer**

This API is provided for testing and development purposes only. Data accuracy is not guaranteed. Users should verify all information independently before making any decisions based on this API's data.

---

*Last Updated: December 19, 2025*
*API Version: 1.0*
