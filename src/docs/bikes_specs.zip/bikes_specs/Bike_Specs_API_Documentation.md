# Bike Specifications API Documentation

**Version:** 1.0  
**Last Updated:** December 19, 2025  
**API Base URL:** `/mockapis/serverpeuser/api/bikespecs`

---

## Table of Contents

1. [Overview](#overview)
2. [Authentication & Authorization](#authentication--authorization)
3. [API Rate Limiting](#api-rate-limiting)
4. [Endpoints](#endpoints)
   - [Bike Makes](#1-get-bike-makes)
   - [Bike Models](#2-get-bike-models)
   - [Bike Types](#3-get-bike-types)
   - [Bike Categories](#4-get-bike-categories)
   - [Bike List](#5-get-bike-list)
   - [Bike Specifications](#6-get-bike-specifications)
   - [Search Bikes](#7-search-bikes)
5. [Response Structure](#response-structure)
6. [Error Handling](#error-handling)
7. [Data Definitions](#data-definitions)
8. [Implementation Notes](#implementation-notes)

---

## Overview

The Bike Specifications API provides comprehensive access to motorcycle and two-wheeler database information including makes (brands), models, types, categories, and detailed specifications. This API enables developers to build bike selection interfaces, search functionality, and specification lookup tools for the Indian two-wheeler market.

### Key Features

- **Hierarchical Bike Data**: Browse bikes by make → model → type → category
- **Detailed Specifications**: Access complete technical specifications for any bike variant
- **Search Functionality**: Full-text search across bike database
- **Rate Limiting & Security**: Advanced security middleware with DDoS protection
- **Performance Optimized**: Cached responses with Redis integration

### Disclaimer

> **CAUTION**: The data provided by these APIs is strictly for UI testing, learning, and training purposes only. No relation exists with any live scenario or actual vehicle specifications.

---

## Authentication & Authorization

All API requests must include valid API credentials.

### Required Headers

```
1) x-api-key       (provided after subscription)
2) x-secret-key    (provided after subscription)
```

### API Key Validation

Requests are validated through the `checkApiKey` middleware. Ensure your API key and secret key are valid before making requests. Each API key has rate-limited call allocations.

---

## API Rate Limiting

The Bike Specifications API implements advanced rate limiting and security measures:

### Rate Limiting Policy

- **Standard Limit:** 3 requests per second
- **Scraper Detection:** 50 requests in 10-second window triggers blocking
- **Block Duration:** 1 hour for detected scrapers
- **Detection Window:** 10 seconds

### Response Header

Each API response includes a `remaining_calls` parameter:

```json
{
  "success": true,
  "remaining_calls": 69,
  "data": { ... }
}
```

**Important**: Monitor this value and implement appropriate error handling when calls are exhausted.

---

## Endpoints

### 1. Get Bike Makes

Retrieves a list of all available bike manufacturers (makes/brands) in the database.

**Endpoint:** `GET /mockapis/serverpeuser/api/bikespecs/bike-makes`

**Method:** GET

**Description:** Fetches complete list of all bike makes/brands without requiring any parameters.

**Headers:**
```
x-api-key: <your-api-key>
x-secret-key: <your-secret-key>
```

**Request Body:** None (GET request)

**Response Structure:**

```json
{
  "success": true,
  "data": [
    {
      "id": 1,
      "make_id": 2001,
      "make_name": "Hero MotoCorp",
      "logo_url": "https://example.com/logo/hero.png"
    },
    {
      "id": 2,
      "make_id": 2002,
      "make_name": "Honda",
      "logo_url": "https://example.com/logo/honda.png"
    },
    {
      "id": 3,
      "make_id": 2003,
      "make_name": "Bajaj",
      "logo_url": "https://example.com/logo/bajaj.png"
    }
  ]
}
```

**Status Codes:**
- `200` - Success
- `500` - Internal Server Error

**Example cURL:**
```bash
curl -X GET "http://localhost:5000/mockapis/serverpeuser/api/bikespecs/bike-makes" \
  -H "x-api-key: your-api-key" \
  -H "x-secret-key: your-secret-key"
```

---

### 2. Get Bike Models

Retrieves all available models for a specified bike brand/make.

**Endpoint:** `POST /mockapis/serverpeuser/api/bikespecs/bike-models`

**Method:** POST

**Description:** Fetches all bike models available for a given brand. Requires brand name as parameter.

**Headers:**
```
x-api-key: <your-api-key>
x-secret-key: <your-secret-key>
Content-Type: application/json
```

**Request Body:**

```json
{
  "brand": "Hero MotoCorp"
}
```

**Request Parameters:**

| Parameter | Type   | Required | Description              | Example           |
|-----------|--------|----------|--------------------------|-------------------|
| brand     | string | Yes      | Bike manufacturer name   | "Hero MotoCorp"   |

**Validation Rules:**
- `brand` field must be present
- `brand` cannot be an empty string

**Response Structure:**

```json
{
  "success": true,
  "remaining_calls": 68,
  "data": [
    {
      "id": 201,
      "model_id": 6001,
      "model_name": "Splendor",
      "make_id": 2001
    },
    {
      "id": 202,
      "model_id": 6002,
      "model_name": "Passion",
      "make_id": 2001
    },
    {
      "id": 203,
      "model_id": 6003,
      "model_name": "HF Deluxe",
      "make_id": 2001
    }
  ]
}
```

**Status Codes:**
- `200` - Success
- `404` - Brand not found or request body missing
- `422` - Invalid brand parameter
- `500` - Internal Server Error

**Error Response Example:**

```json
{
  "success": true,
  "remaining_calls": 68,
  "data": {
    "statuscode": 404,
    "successstatus": false,
    "message": "brand not found!"
  }
}
```

**Example cURL:**
```bash
curl -X POST "http://localhost:5000/mockapis/serverpeuser/api/bikespecs/bike-models" \
  -H "x-api-key: your-api-key" \
  -H "x-secret-key: your-secret-key" \
  -H "Content-Type: application/json" \
  -d '{"brand": "Hero MotoCorp"}'
```

---

### 3. Get Bike Types

Retrieves all available bike types for a specified brand and model combination.

**Endpoint:** `POST /mockapis/serverpeuser/api/bikespecs/bike-type`

**Method:** POST

**Description:** Fetches all bike types (motorcycle, scooter, moped, etc.) available for a given brand-model combination.

**Headers:**
```
x-api-key: <your-api-key>
x-secret-key: <your-secret-key>
Content-Type: application/json
```

**Request Body:**

```json
{
  "brand": "Hero MotoCorp",
  "model": "Splendor"
}
```

**Request Parameters:**

| Parameter | Type   | Required | Description            | Example           |
|-----------|--------|----------|------------------------|-------------------|
| brand     | string | Yes      | Bike manufacturer name | "Hero MotoCorp"   |
| model     | string | Yes      | Bike model name        | "Splendor"        |

**Validation Rules:**
- Both `brand` and `model` fields must be present
- Neither field can be an empty string

**Response Structure:**

```json
{
  "success": true,
  "remaining_calls": 67,
  "data": [
    {
      "id": 3001,
      "type_id": 9001,
      "type_name": "Commuter",
      "model_id": 6001
    },
    {
      "id": 3002,
      "type_id": 9002,
      "type_name": "Sports",
      "model_id": 6001
    }
  ]
}
```

**Status Codes:**
- `200` - Success
- `404` - Brand/Model not found or request body missing
- `422` - Invalid brand or model parameter
- `500` - Internal Server Error

**Error Response Example:**

```json
{
  "success": true,
  "remaining_calls": 67,
  "data": {
    "statuscode": 404,
    "successstatus": false,
    "message": "model not found!"
  }
}
```

**Example cURL:**
```bash
curl -X POST "http://localhost:5000/mockapis/serverpeuser/api/bikespecs/bike-type" \
  -H "x-api-key: your-api-key" \
  -H "x-secret-key: your-secret-key" \
  -H "Content-Type: application/json" \
  -d '{"brand": "Hero MotoCorp", "model": "Splendor"}'
```

---

### 4. Get Bike Categories

Retrieves all available categories for a specified brand, model, and bike type combination.

**Endpoint:** `POST /mockapis/serverpeuser/api/bikespecs/bike-category`

**Method:** POST

**Description:** Fetches all bike categories available for a given brand-model-type combination.

**Headers:**
```
x-api-key: <your-api-key>
x-secret-key: <your-secret-key>
Content-Type: application/json
```

**Request Body:**

```json
{
  "brand": "Hero MotoCorp",
  "model": "Splendor",
  "bike_type": "Commuter"
}
```

**Request Parameters:**

| Parameter | Type   | Required | Description            | Example           |
|-----------|--------|----------|------------------------|-------------------|
| brand     | string | Yes      | Bike manufacturer name | "Hero MotoCorp"   |
| model     | string | Yes      | Bike model name        | "Splendor"        |
| bike_type | string | Yes      | Bike type              | "Commuter"        |

**Validation Rules:**
- All three fields (`brand`, `model`, `bike_type`) must be present
- None of the fields can be empty strings

**Response Structure:**

```json
{
  "success": true,
  "remaining_calls": 66,
  "data": [
    {
      "id": 4001,
      "category_id": 10001,
      "category_name": "Standard",
      "type_id": 9001,
      "price": 65000
    },
    {
      "id": 4002,
      "category_id": 10002,
      "category_name": "Deluxe",
      "type_id": 9001,
      "price": 75000
    }
  ]
}
```

**Status Codes:**
- `200` - Success
- `404` - Brand/Model/Type not found or request body missing
- `422` - Invalid parameter
- `500` - Internal Server Error

**Error Response Example:**

```json
{
  "success": true,
  "remaining_calls": 66,
  "data": {
    "statuscode": 404,
    "successstatus": false,
    "message": "bike_type not found!"
  }
}
```

**Example cURL:**
```bash
curl -X POST "http://localhost:5000/mockapis/serverpeuser/api/bikespecs/bike-category" \
  -H "x-api-key: your-api-key" \
  -H "x-secret-key: your-secret-key" \
  -H "Content-Type: application/json" \
  -d '{"brand": "Hero MotoCorp", "model": "Splendor", "bike_type": "Commuter"}'
```

---

### 5. Get Bike List

Retrieves detailed bike records for a specified brand, model, type, and category combination.

**Endpoint:** `POST /mockapis/serverpeuser/api/bikespecs/bike-list`

**Method:** POST

**Description:** Fetches complete bike list with basic information for a given brand-model-type-category combination.

**Headers:**
```
x-api-key: <your-api-key>
x-secret-key: <your-secret-key>
Content-Type: application/json
```

**Request Body:**

```json
{
  "brand": "Hero MotoCorp",
  "model": "Splendor",
  "bike_type": "Commuter",
  "category": "Standard"
}
```

**Request Parameters:**

| Parameter | Type   | Required | Description              | Example           |
|-----------|--------|----------|--------------------------|-------------------|
| brand     | string | Yes      | Bike manufacturer name   | "Hero MotoCorp"   |
| model     | string | Yes      | Bike model name          | "Splendor"        |
| bike_type | string | Yes      | Bike type                | "Commuter"        |
| category  | string | Yes      | Bike category/variant    | "Standard"        |

**Validation Rules:**
- All four fields must be present
- None of the fields can be empty strings

**Response Structure:**

```json
{
  "success": true,
  "remaining_calls": 65,
  "data": [
    {
      "id": 50001,
      "bike_id": "SPLENDOR_COMMUTER_STANDARD_001",
      "year": 2024,
      "color": "Black",
      "transmission": "Manual",
      "fuel_type": "Petrol",
      "engine_capacity": "97cc",
      "price": 65000,
      "category_id": 10001
    },
    {
      "id": 50002,
      "bike_id": "SPLENDOR_COMMUTER_STANDARD_002",
      "year": 2024,
      "color": "Red",
      "transmission": "Manual",
      "fuel_type": "Petrol",
      "engine_capacity": "97cc",
      "price": 65000,
      "category_id": 10001
    }
  ]
}
```

**Status Codes:**
- `200` - Success
- `404` - Brand/Model/Type/Category not found or request body missing
- `422` - Invalid parameter
- `500` - Internal Server Error

**Error Response Example:**

```json
{
  "success": true,
  "remaining_calls": 65,
  "data": {
    "statuscode": 404,
    "successstatus": false,
    "message": "category not found!"
  }
}
```

**Example cURL:**
```bash
curl -X POST "http://localhost:5000/mockapis/serverpeuser/api/bikespecs/bike-list" \
  -H "x-api-key: your-api-key" \
  -H "x-secret-key: your-secret-key" \
  -H "Content-Type: application/json" \
  -d '{"brand": "Hero MotoCorp", "model": "Splendor", "bike_type": "Commuter", "category": "Standard"}'
```

---

### 6. Get Bike Specifications

Retrieves detailed technical specifications for a specific bike variant by ID.

**Endpoint:** `POST /mockapis/serverpeuser/api/bikespecs/bike-specs`

**Method:** POST

**Description:** Fetches comprehensive technical specifications for a bike variant identified by its unique ID.

**Headers:**
```
x-api-key: <your-api-key>
x-secret-key: <your-secret-key>
Content-Type: application/json
```

**Request Body:**

```json
{
  "id": 50001
}
```

**Request Parameters:**

| Parameter | Type    | Required | Description                    | Example |
|-----------|---------|----------|--------------------------------|---------|
| id        | integer | Yes      | Unique bike variant identifier | 50001   |

**Validation Rules:**
- `id` field must be present
- `id` must be a valid numeric value

**Response Structure:**

```json
{
  "success": true,
  "remaining_calls": 64,
  "data": {
    "id": 50001,
    "bike_id": "SPLENDOR_COMMUTER_STANDARD_001",
    "year": 2024,
    "make": "Hero MotoCorp",
    "model": "Splendor",
    "type": "Commuter",
    "category": "Standard",
    "color": "Black",
    "transmission": "Manual",
    "fuel_type": "Petrol",
    "engine_capacity": "97cc",
    "max_power": "8 bhp",
    "torque": "8 Nm",
    "acceleration_0_60": "8.2 seconds",
    "top_speed": "120 km/h",
    "mileage": "72 km/l",
    "seating_capacity": 2,
    "fuel_tank_capacity": "9 litres",
    "length": "1968 mm",
    "width": "740 mm",
    "height": "1130 mm",
    "ground_clearance": "165 mm",
    "kerb_weight": "107 kg",
    "price": 65000,
    "warranty": "3 years / 50,000 km",
    "features": [
      "Digital Speedometer",
      "Semi-Digital Console",
      "Kick Start"
    ],
    "safety_features": [
      "Engine Kill Switch",
      "Safety Fuses"
    ]
  }
}
```

**Status Codes:**
- `200` - Success
- `404` - Bike ID not found or request body missing
- `422` - Invalid ID parameter (non-numeric)
- `500` - Internal Server Error

**Error Response Example:**

```json
{
  "success": true,
  "remaining_calls": 64,
  "data": {
    "statuscode": 422,
    "successstatus": false,
    "message": "id is invalid!"
  }
}
```

**Example cURL:**
```bash
curl -X POST "http://localhost:5000/mockapis/serverpeuser/api/bikespecs/bike-specs" \
  -H "x-api-key: your-api-key" \
  -H "x-secret-key: your-secret-key" \
  -H "Content-Type: application/json" \
  -d '{"id": 50001}'
```

---

### 7. Search Bikes

Performs full-text search across the bike database with pagination support.

**Endpoint:** `POST /mockapis/serverpeuser/api/bikespecs/search-bikes`

**Method:** POST

**Description:** Searches for bikes matching the query string across brand, model, type, and category fields with pagination support.

**Headers:**
```
x-api-key: <your-api-key>
x-secret-key: <your-secret-key>
Content-Type: application/json
```

**Request Body:**

```json
{
  "query": "Splendor",
  "limit": 20,
  "skip": 0
}
```

**Request Parameters:**

| Parameter | Type    | Required | Description                          | Example       |
|-----------|---------|----------|--------------------------------------|---------------|
| query     | string  | Yes      | Search query string                  | "Splendor"    |
| limit     | integer | Yes      | Number of results to return          | 20            |
| skip      | integer | Yes      | Number of results to skip (offset)   | 0             |

**Validation Rules:**
- `query` field must be present
- `query` cannot be an empty string
- `limit` must be a valid numeric value
- `skip` must be a valid numeric value

**Response Structure:**

```json
{
  "success": true,
  "remaining_calls": 63,
  "data": {
    "total_results": 12,
    "returned_results": 12,
    "limit": 20,
    "skip": 0,
    "results": [
      {
        "id": 50001,
        "bike_id": "SPLENDOR_COMMUTER_STANDARD_001",
        "make": "Hero MotoCorp",
        "model": "Splendor",
        "type": "Commuter",
        "category": "Standard",
        "year": 2024,
        "price": 65000,
        "fuel_type": "Petrol",
        "transmission": "Manual"
      },
      {
        "id": 50002,
        "bike_id": "SPLENDOR_COMMUTER_STANDARD_002",
        "make": "Hero MotoCorp",
        "model": "Splendor",
        "type": "Commuter",
        "category": "Standard",
        "year": 2024,
        "price": 65000,
        "fuel_type": "Petrol",
        "transmission": "Manual"
      }
    ]
  }
}
```

**Status Codes:**
- `200` - Success
- `404` - Query not found or request body missing
- `422` - Invalid query, limit, or skip parameter
- `500` - Internal Server Error

**Error Response Example:**

```json
{
  "success": true,
  "remaining_calls": 63,
  "data": {
    "statuscode": 422,
    "successstatus": false,
    "message": "limit is invalid!"
  }
}
```

**Example cURL:**
```bash
curl -X POST "http://localhost:5000/mockapis/serverpeuser/api/bikespecs/search-bikes" \
  -H "x-api-key: your-api-key" \
  -H "x-secret-key: your-secret-key" \
  -H "Content-Type: application/json" \
  -d '{"query": "Splendor", "limit": 20, "skip": 0}'
```

---

## Response Structure

### Standard Success Response

All successful API responses follow this structure:

```json
{
  "success": true,
  "remaining_calls": 70,
  "data": { /* endpoint-specific data */ }
}
```

### Standard Error Response

Error responses maintain the same structure:

```json
{
  "success": true,
  "remaining_calls": 70,
  "data": {
    "statuscode": 404,
    "successstatus": false,
    "message": "Detailed error message"
  }
}
```

---

## Error Handling

### HTTP Status Codes

| Status Code | Meaning                              |
|-------------|--------------------------------------|
| 200         | Request successful                   |
| 400         | Bad request                          |
| 404         | Resource not found                   |
| 422         | Unprocessable entity (validation)    |
| 429         | Too many requests (rate limited)     |
| 500         | Internal server error                |

### Common Error Messages

| Message                                    | Cause                                    |
|--------------------------------------------|------------------------------------------|
| "Request body information not found!"     | Missing request body                     |
| "brand not found!"                        | `brand` parameter missing               |
| "brand is invalid!"                       | `brand` parameter is empty string        |
| "model not found!"                        | `model` parameter missing               |
| "model is invalid!"                       | `model` parameter is empty string        |
| "bike_type not found!"                    | `bike_type` parameter missing           |
| "bike_type is invalid!"                   | `bike_type` parameter is empty string    |
| "category not found!"                     | `category` parameter missing            |
| "category is invalid!"                    | `category` parameter is empty string     |
| "id not found!"                           | `id` parameter missing                  |
| "id is invalid!"                          | `id` parameter is non-numeric            |
| "search query not found!"                 | `query` parameter missing               |
| "search query is invalid!"                | `query` parameter is empty string        |
| "limit is invalid!"                       | `limit` parameter is non-numeric         |
| "skip is invalid!"                        | `skip` parameter is non-numeric          |
| "Internal Server Error"                   | Server-side error occurred               |

### Error Handling Best Practices

1. **Always check the `success` field** in the response
2. **Monitor `remaining_calls`** to avoid exceeding rate limits
3. **Implement exponential backoff** for retry logic
4. **Log error responses** for debugging purposes
5. **Handle rate limiting gracefully** with appropriate user feedback

---

## Data Definitions

### Make Object

```json
{
  "id": 1,
  "make_id": 2001,
  "make_name": "Hero MotoCorp",
  "logo_url": "https://example.com/logo/hero.png"
}
```

| Field    | Type   | Description                  |
|----------|--------|------------------------------|
| id       | int    | Internal database ID         |
| make_id  | int    | Unique manufacturer ID       |
| make_name| string | Manufacturer name            |
| logo_url | string | URL to manufacturer logo     |

### Model Object

```json
{
  "id": 201,
  "model_id": 6001,
  "model_name": "Splendor",
  "make_id": 2001
}
```

| Field    | Type | Description            |
|----------|------|------------------------|
| id       | int  | Internal database ID   |
| model_id | int  | Unique model ID        |
| model_name| string| Bike model name       |
| make_id  | int  | Parent make ID        |

### Bike Type Object

```json
{
  "id": 3001,
  "type_id": 9001,
  "type_name": "Commuter",
  "model_id": 6001
}
```

| Field    | Type   | Description            |
|----------|--------|------------------------|
| id       | int    | Internal database ID   |
| type_id  | int    | Unique type ID         |
| type_name| string | Bike type name         |
| model_id | int    | Parent model ID        |

### Category Object

```json
{
  "id": 4001,
  "category_id": 10001,
  "category_name": "Standard",
  "type_id": 9001,
  "price": 65000
}
```

| Field       | Type    | Description            |
|-------------|---------|------------------------|
| id          | int     | Internal database ID   |
| category_id | int     | Unique category ID     |
| category_name| string  | Category name          |
| type_id     | int     | Parent type ID         |
| price       | float   | Price in INR           |

### Bike Specifications Object

```json
{
  "id": 50001,
  "bike_id": "SPLENDOR_COMMUTER_STANDARD_001",
  "year": 2024,
  "make": "Hero MotoCorp",
  "model": "Splendor",
  "type": "Commuter",
  "category": "Standard",
  "color": "Black",
  "transmission": "Manual",
  "fuel_type": "Petrol",
  "engine_capacity": "97cc",
  "max_power": "8 bhp",
  "torque": "8 Nm",
  "acceleration_0_60": "8.2 seconds",
  "top_speed": "120 km/h",
  "mileage": "72 km/l",
  "seating_capacity": 2,
  "fuel_tank_capacity": "9 litres",
  "length": "1968 mm",
  "width": "740 mm",
  "height": "1130 mm",
  "ground_clearance": "165 mm",
  "kerb_weight": "107 kg",
  "price": 65000,
  "warranty": "3 years / 50,000 km",
  "features": [],
  "safety_features": []
}
```

| Field              | Type     | Description                      |
|-------------------|----------|----------------------------------|
| id                | int      | Internal database ID             |
| bike_id           | string   | Unique bike identifier           |
| year              | int      | Model year                       |
| make              | string   | Manufacturer name                |
| model             | string   | Model name                       |
| type              | string   | Bike type                        |
| category          | string   | Category/variant name            |
| color             | string   | Bike color                       |
| transmission      | string   | Manual/Automatic                 |
| fuel_type         | string   | Petrol/Diesel/Electric           |
| engine_capacity   | string   | Engine displacement              |
| max_power         | string   | Maximum power output             |
| torque            | string   | Maximum torque                   |
| acceleration_0_60 | string   | 0-60 km/h time                   |
| top_speed         | string   | Maximum speed                    |
| mileage           | string   | Fuel efficiency (km/l)           |
| seating_capacity  | int      | Number of seats                  |
| fuel_tank_capacity| string   | Fuel tank volume                 |
| length            | string   | Overall length                   |
| width             | string   | Overall width                    |
| height            | string   | Overall height                   |
| ground_clearance  | string   | Ground clearance                 |
| kerb_weight       | string   | Vehicle weight                   |
| price             | float    | Price in INR                     |
| warranty          | string   | Warranty period and coverage     |
| features          | array    | List of bike features            |
| safety_features   | array    | List of safety features          |

---

## Implementation Notes

### Performance Optimization

1. **Caching Strategy**: Responses are cached using Redis for improved performance
2. **Connection Pooling**: Database connections are pooled and reused
3. **Query Optimization**: SQL queries are optimized for fast execution
4. **Index Strategy**: Database indexes on frequently searched fields

### Security Measures

1. **API Key Validation**: All requests validated against registered API keys
2. **DDoS Protection**: Advanced rate limiting detects and blocks scrapers
3. **Request Validation**: Input parameters validated before database queries
4. **SQL Injection Prevention**: Parameterized queries prevent SQL injection
5. **TLS Support**: Redis connections use TLS for secure data transmission

### Best Practices for API Integration

1. **Use Connection Pooling**: Reuse connections for multiple requests
2. **Implement Retry Logic**: Handle transient failures with exponential backoff
3. **Cache Results Locally**: Cache frequently accessed data on the client side
4. **Batch Operations**: Combine multiple queries when possible
5. **Monitor Usage**: Track `remaining_calls` to optimize API usage
6. **Error Logging**: Log all errors for debugging and monitoring
7. **Timeout Handling**: Implement request timeouts to prevent hanging

### Rate Limiting Strategy

- **Recommended Request Pattern**: Use 1-2 requests per second
- **Batch Size**: Limit concurrent requests to 5-10
- **Retry Delay**: Use exponential backoff (100ms, 200ms, 400ms, ...)
- **Peak Usage**: Avoid high-frequency requests during peak hours

### Known Limitations

1. Search results limited to 1000 records maximum
2. Single request limit: 100 records per pagination
3. Make list is static and updated quarterly
4. Specifications may vary based on data source

---

## Changelog

### Version 1.0 (December 19, 2025)

- Initial release
- 7 core endpoints for bike data retrieval
- Full-text search functionality
- Advanced rate limiting and security
- Comprehensive error handling

---

**Support & Documentation**

For additional support and technical documentation, please refer to:
- API Dashboard: https://dashboard.serverpe.com
- Support Email: support@serverpe.com
- Status Page: https://status.serverpe.com

---

**Disclaimer**

This API is provided for testing and development purposes only. Data accuracy is not guaranteed. Users should verify all information independently before making any decisions based on this API's data.

---

*Last Updated: December 19, 2025*
*API Version: 1.0*
